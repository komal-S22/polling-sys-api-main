# Polling System API
A simple Polling System API developed using Node.js, Express.js and Mongodb for storing data in Database.It is used for voting. For Setting up on your system you have to do following steps.

## 1. Git Clone
You have to open you Visual Studio code.
Open Terminal and Type git clone https://github.com/bhushanverma1998/polling-sys-api.git
It will download the files on you system.

## 2. Include node_modules
For Starting the Project first you need to install all node modules.
Open Terminal and Type npm install.
It will download all dependencies files.

## 3. Start Server
For Starting the Server.
Open Terminal and Type npm run dev.
It will Start the server on port 5000.

## 4. Running API
You can use POSTMAN or THUNDER CLIENT[It is an extension inside VSCode].